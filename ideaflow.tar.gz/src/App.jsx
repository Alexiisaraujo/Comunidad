import { useState, useEffect } from "react";
import { Lightbulb, Lock, Globe, Users, Plus, LogOut, User, ChevronRight, X, Check, Bell, Edit2, Trash2, Eye } from "lucide-react";

const STORAGE_KEY = "ideaflow_data";

function getStorage() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || { users: [], ideas: [], requests: [] };
  } catch {
    return { users: [], ideas: [], requests: [] };
  }
}

function saveStorage(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

const VISIBILITY = {
  public: { label: "Pública", icon: Globe, color: "#16a34a", bg: "#dcfce7" },
  private: { label: "Privada", icon: Lock, color: "#6b7280", bg: "#f3f4f6" },
  collab: { label: "Colaborativa", icon: Users, color: "#2563eb", bg: "#dbeafe" },
};

export default function App() {
  const [db, setDb] = useState(getStorage);
  const [currentUser, setCurrentUser] = useState(null);
  const [view, setView] = useState("auth"); // auth | home | profile | explore | notifications
  const [authMode, setAuthMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [ideaForm, setIdeaForm] = useState({ title: "", description: "", visibility: "public" });
  const [showNewIdea, setShowNewIdea] = useState(false);
  const [editIdea, setEditIdea] = useState(null);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [selectedIdea, setSelectedIdea] = useState(null);

  useEffect(() => { saveStorage(db); }, [db]);

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(""), 2500);
  }

  function register() {
    if (!form.name || !form.email || !form.password) return setError("Completá todos los campos");
    if (db.users.find(u => u.email === form.email)) return setError("Ya existe ese email");
    const user = { id: Date.now().toString(), name: form.name, email: form.email, password: form.password, bio: "", avatar: form.name[0].toUpperCase() };
    const newDb = { ...db, users: [...db.users, user] };
    setDb(newDb);
    setCurrentUser(user);
    setView("home");
    setError("");
  }

  function login() {
    if (!form.email || !form.password) return setError("Completá todos los campos");
    const user = db.users.find(u => u.email === form.email && u.password === form.password);
    if (!user) return setError("Email o contraseña incorrectos");
    setCurrentUser(user);
    setView("home");
    setError("");
  }

  function logout() {
    setCurrentUser(null);
    setView("auth");
    setForm({ name: "", email: "", password: "" });
  }

  function saveIdea() {
    if (!ideaForm.title.trim()) return;
    if (editIdea) {
      const newDb = { ...db, ideas: db.ideas.map(i => i.id === editIdea.id ? { ...i, ...ideaForm } : i) };
      setDb(newDb);
      setEditIdea(null);
      showToast("Idea actualizada ✓");
    } else {
      const idea = { id: Date.now().toString(), userId: currentUser.id, ...ideaForm, createdAt: new Date().toLocaleDateString("es-AR") };
      setDb(prev => ({ ...prev, ideas: [idea, ...prev.ideas] }));
      showToast("Idea guardada ✓");
    }
    setIdeaForm({ title: "", description: "", visibility: "public" });
    setShowNewIdea(false);
  }

  function deleteIdea(id) {
    setDb(prev => ({ ...prev, ideas: prev.ideas.filter(i => i.id !== id) }));
    showToast("Idea eliminada");
  }

  function requestCollab(ideaId) {
    const already = db.requests.find(r => r.ideaId === ideaId && r.fromId === currentUser.id);
    if (already) return showToast("Ya enviaste una solicitud");
    const req = { id: Date.now().toString(), ideaId, fromId: currentUser.id, fromName: currentUser.name, status: "pending", createdAt: new Date().toLocaleDateString("es-AR") };
    setDb(prev => ({ ...prev, requests: [...prev.requests, req] }));
    showToast("Solicitud enviada ✓");
  }

  function handleRequest(reqId, accept) {
    setDb(prev => ({ ...prev, requests: prev.requests.map(r => r.id === reqId ? { ...r, status: accept ? "accepted" : "rejected" } : r) }));
    showToast(accept ? "Solicitud aceptada" : "Solicitud rechazada");
  }

  const myIdeas = db.ideas.filter(i => i.userId === currentUser?.id);
  const publicIdeas = db.ideas.filter(i => i.visibility === "public" && i.userId !== currentUser?.id);
  const collabIdeas = db.ideas.filter(i => i.visibility === "collab" && i.userId !== currentUser?.id);
  const exploreIdeas = [...publicIdeas, ...collabIdeas];
  const myRequests = db.requests.filter(r => {
    const idea = db.ideas.find(i => i.id === r.ideaId);
    return idea?.userId === currentUser?.id;
  });
  const pendingCount = myRequests.filter(r => r.status === "pending").length;

  function getUserName(id) {
    return db.users.find(u => u.id === id)?.name || "Usuario";
  }

  if (view === "auth") return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--color-background-secondary)", padding: "1rem" }}>
      <div style={{ width: "100%", maxWidth: 380 }}>
        <div style={{ textAlign: "center", marginBottom: "2rem" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <Lightbulb size={28} color="#e94560" />
            <span style={{ fontSize: 26, fontWeight: 600, color: "var(--color-text-primary)", letterSpacing: -0.5 }}>IdeaFlow</span>
          </div>
          <p style={{ fontSize: 14, color: "var(--color-text-secondary)" }}>Tu espacio para ideas de negocios</p>
        </div>

        <div style={{ background: "var(--color-background-primary)", borderRadius: 16, border: "0.5px solid var(--color-border-tertiary)", padding: "1.75rem" }}>
          <div style={{ display: "flex", marginBottom: "1.5rem", background: "var(--color-background-secondary)", borderRadius: 8, padding: 3 }}>
            {["login", "register"].map(m => (
              <button key={m} onClick={() => { setAuthMode(m); setError(""); }} style={{ flex: 1, padding: "8px", border: "none", borderRadius: 6, cursor: "pointer", fontSize: 14, fontFamily: "var(--font-sans)", background: authMode === m ? "var(--color-background-primary)" : "transparent", color: authMode === m ? "var(--color-text-primary)" : "var(--color-text-secondary)", fontWeight: authMode === m ? 500 : 400, transition: "all 0.15s" }}>
                {m === "login" ? "Entrar" : "Registrarse"}
              </button>
            ))}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {authMode === "register" && <input placeholder="Tu nombre" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} style={inputStyle} />}
            <input placeholder="Email" type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} style={inputStyle} />
            <input placeholder="Contraseña" type="password" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} onKeyDown={e => e.key === "Enter" && (authMode === "login" ? login() : register())} style={inputStyle} />
          </div>

          {error && <p style={{ color: "#e94560", fontSize: 13, marginTop: 10 }}>{error}</p>}

          <button onClick={authMode === "login" ? login : register} style={{ ...btnPrimary, width: "100%", marginTop: 16, justifyContent: "center" }}>
            {authMode === "login" ? "Entrar" : "Crear cuenta"}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "var(--color-background-secondary)", fontFamily: "var(--font-sans)" }}>
      {/* Nav */}
      <div style={{ background: "var(--color-background-primary)", borderBottom: "0.5px solid var(--color-border-tertiary)", position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ maxWidth: 680, margin: "0 auto", padding: "0 1rem", height: 56, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <Lightbulb size={20} color="#e94560" />
            <span style={{ fontWeight: 600, fontSize: 17, letterSpacing: -0.3, color: "var(--color-text-primary)" }}>IdeaFlow</span>
          </div>
          <div style={{ display: "flex", gap: 2 }}>
            {[["home", "Mis ideas"], ["explore", "Explorar"], ["profile", "Perfil"]].map(([v, label]) => (
              <button key={v} onClick={() => setView(v)} style={{ padding: "6px 12px", border: "none", borderRadius: 8, cursor: "pointer", fontSize: 13, fontFamily: "var(--font-sans)", background: view === v ? "var(--color-background-secondary)" : "transparent", color: view === v ? "var(--color-text-primary)" : "var(--color-text-secondary)", fontWeight: view === v ? 500 : 400 }}>
                {label}
              </button>
            ))}
            <button onClick={() => setView("notifications")} style={{ padding: "6px 10px", border: "none", borderRadius: 8, cursor: "pointer", background: view === "notifications" ? "var(--color-background-secondary)" : "transparent", position: "relative", color: "var(--color-text-secondary)" }}>
              <Bell size={18} />
              {pendingCount > 0 && <span style={{ position: "absolute", top: 4, right: 4, width: 8, height: 8, borderRadius: "50%", background: "#e94560" }} />}
            </button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 680, margin: "0 auto", padding: "1.5rem 1rem" }}>

        {/* HOME */}
        {view === "home" && (
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1.25rem" }}>
              <div>
                <h1 style={{ fontSize: 20, fontWeight: 600, color: "var(--color-text-primary)" }}>Mis ideas</h1>
                <p style={{ fontSize: 13, color: "var(--color-text-secondary)", marginTop: 2 }}>{myIdeas.length} idea{myIdeas.length !== 1 ? "s" : ""}</p>
              </div>
              <button onClick={() => { setShowNewIdea(true); setEditIdea(null); setIdeaForm({ title: "", description: "", visibility: "public" }); }} style={btnPrimary}>
                <Plus size={16} /> Nueva idea
              </button>
            </div>

            {(showNewIdea || editIdea) && (
              <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-secondary)", borderRadius: 16, padding: "1.25rem", marginBottom: "1.25rem" }}>
                <input placeholder="Título de tu idea..." value={ideaForm.title} onChange={e => setIdeaForm(p => ({ ...p, title: e.target.value }))} style={{ ...inputStyle, marginBottom: 10 }} />
                <textarea placeholder="Describí tu idea... ¿qué problema resuelve? ¿cómo funciona?" value={ideaForm.description} onChange={e => setIdeaForm(p => ({ ...p, description: e.target.value }))} style={{ ...inputStyle, minHeight: 80, resize: "vertical" }} />
                <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
                  {Object.entries(VISIBILITY).map(([key, val]) => {
                    const Icon = val.icon;
                    const active = ideaForm.visibility === key;
                    return (
                      <button key={key} onClick={() => setIdeaForm(p => ({ ...p, visibility: key }))} style={{ display: "flex", alignItems: "center", gap: 5, padding: "6px 12px", border: active ? `1.5px solid ${val.color}` : "0.5px solid var(--color-border-tertiary)", borderRadius: 20, background: active ? val.bg : "transparent", color: active ? val.color : "var(--color-text-secondary)", cursor: "pointer", fontSize: 13, fontFamily: "var(--font-sans)", fontWeight: active ? 500 : 400 }}>
                        <Icon size={13} /> {val.label}
                      </button>
                    );
                  })}
                </div>
                {ideaForm.visibility === "collab" && <p style={{ fontSize: 12, color: "#2563eb", marginTop: 8 }}>Otros usuarios podrán solicitar unirse a esta idea</p>}
                <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                  <button onClick={saveIdea} style={btnPrimary}><Check size={15} /> {editIdea ? "Guardar cambios" : "Publicar idea"}</button>
                  <button onClick={() => { setShowNewIdea(false); setEditIdea(null); }} style={btnGhost}><X size={15} /> Cancelar</button>
                </div>
              </div>
            )}

            {myIdeas.length === 0 && !showNewIdea && (
              <div style={{ textAlign: "center", padding: "3rem 1rem", color: "var(--color-text-secondary)" }}>
                <Lightbulb size={40} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
                <p style={{ fontSize: 15 }}>Todavía no tenés ideas</p>
                <p style={{ fontSize: 13, marginTop: 4 }}>Tocá "Nueva idea" para empezar</p>
              </div>
            )}

            {myIdeas.map(idea => <IdeaCard key={idea.id} idea={idea} mine onEdit={() => { setEditIdea(idea); setIdeaForm({ title: idea.title, description: idea.description, visibility: idea.visibility }); setShowNewIdea(false); }} onDelete={() => deleteIdea(idea.id)} onView={() => setSelectedIdea(idea)} />)}
          </div>
        )}

        {/* EXPLORE */}
        {view === "explore" && (
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 600, color: "var(--color-text-primary)", marginBottom: 4 }}>Explorar ideas</h1>
            <p style={{ fontSize: 13, color: "var(--color-text-secondary)", marginBottom: "1.25rem" }}>{exploreIdeas.length} idea{exploreIdeas.length !== 1 ? "s" : ""} de la comunidad</p>

            {exploreIdeas.length === 0 && (
              <div style={{ textAlign: "center", padding: "3rem 1rem", color: "var(--color-text-secondary)" }}>
                <Globe size={40} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
                <p style={{ fontSize: 15 }}>No hay ideas públicas todavía</p>
                <p style={{ fontSize: 13, marginTop: 4 }}>Invitá a un amigo y compartan ideas</p>
              </div>
            )}

            {exploreIdeas.map(idea => {
              const alreadyRequested = db.requests.find(r => r.ideaId === idea.id && r.fromId === currentUser.id);
              return <IdeaCard key={idea.id} idea={idea} author={getUserName(idea.userId)} onRequest={idea.visibility === "collab" ? () => requestCollab(idea.id) : null} alreadyRequested={!!alreadyRequested} onView={() => setSelectedIdea(idea)} />;
            })}
          </div>
        )}

        {/* NOTIFICATIONS */}
        {view === "notifications" && (
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "1.25rem" }}>Solicitudes</h1>
            {myRequests.length === 0 && (
              <div style={{ textAlign: "center", padding: "3rem 1rem", color: "var(--color-text-secondary)" }}>
                <Bell size={40} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
                <p style={{ fontSize: 15 }}>Sin solicitudes por ahora</p>
              </div>
            )}
            {myRequests.map(req => {
              const idea = db.ideas.find(i => i.id === req.ideaId);
              return (
                <div key={req.id} style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 12, padding: "1rem 1.25rem", marginBottom: 10 }}>
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
                    <div>
                      <p style={{ fontSize: 14, fontWeight: 500, color: "var(--color-text-primary)" }}>{req.fromName}</p>
                      <p style={{ fontSize: 13, color: "var(--color-text-secondary)", marginTop: 2 }}>quiere unirse a <strong>{idea?.title}</strong></p>
                      <p style={{ fontSize: 12, color: "var(--color-text-secondary)", marginTop: 2 }}>{req.createdAt}</p>
                    </div>
                    {req.status === "pending" ? (
                      <div style={{ display: "flex", gap: 6 }}>
                        <button onClick={() => handleRequest(req.id, true)} style={{ padding: "6px 12px", background: "#dcfce7", color: "#16a34a", border: "none", borderRadius: 8, cursor: "pointer", fontSize: 13, fontFamily: "var(--font-sans)", fontWeight: 500 }}>Aceptar</button>
                        <button onClick={() => handleRequest(req.id, false)} style={{ padding: "6px 12px", background: "var(--color-background-secondary)", color: "var(--color-text-secondary)", border: "none", borderRadius: 8, cursor: "pointer", fontSize: 13, fontFamily: "var(--font-sans)" }}>Rechazar</button>
                      </div>
                    ) : (
                      <span style={{ fontSize: 12, padding: "4px 10px", borderRadius: 20, background: req.status === "accepted" ? "#dcfce7" : "var(--color-background-secondary)", color: req.status === "accepted" ? "#16a34a" : "var(--color-text-secondary)" }}>{req.status === "accepted" ? "Aceptado" : "Rechazado"}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* PROFILE */}
        {view === "profile" && (
          <ProfileView user={currentUser} myIdeas={myIdeas} onLogout={logout} onSave={(updated) => {
            const newDb = { ...db, users: db.users.map(u => u.id === currentUser.id ? updated : u) };
            setDb(newDb);
            setCurrentUser(updated);
            showToast("Perfil actualizado ✓");
          }} />
        )}
      </div>

      {/* Modal ver idea */}
      {selectedIdea && (
        <div onClick={() => setSelectedIdea(null)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 50, display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" }}>
          <div onClick={e => e.stopPropagation()} style={{ background: "var(--color-background-primary)", borderRadius: 16, padding: "1.5rem", width: "100%", maxWidth: 480, maxHeight: "80vh", overflowY: "auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
              <VisBadge v={selectedIdea.visibility} />
              <button onClick={() => setSelectedIdea(null)} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--color-text-secondary)" }}><X size={18} /></button>
            </div>
            <h2 style={{ fontSize: 20, fontWeight: 600, color: "var(--color-text-primary)", marginBottom: 8 }}>{selectedIdea.title}</h2>
            <p style={{ fontSize: 14, color: "var(--color-text-secondary)", lineHeight: 1.6 }}>{selectedIdea.description || "Sin descripción."}</p>
            <p style={{ fontSize: 12, color: "var(--color-text-secondary)", marginTop: 12 }}>{selectedIdea.createdAt}</p>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", background: "var(--color-text-primary)", color: "var(--color-background-primary)", padding: "10px 20px", borderRadius: 20, fontSize: 14, zIndex: 100, whiteSpace: "nowrap" }}>
          {toast}
        </div>
      )}
    </div>
  );
}

function IdeaCard({ idea, mine, onEdit, onDelete, author, onRequest, alreadyRequested, onView }) {
  const vis = VISIBILITY[idea.visibility];
  const Icon = vis.icon;
  return (
    <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 12, padding: "1rem 1.25rem", marginBottom: 10, transition: "border-color 0.15s" }}
      onMouseEnter={e => e.currentTarget.style.borderColor = "var(--color-border-secondary)"}
      onMouseLeave={e => e.currentTarget.style.borderColor = "var(--color-border-tertiary)"}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, flexWrap: "wrap" }}>
            <VisBadge v={idea.visibility} />
            {author && <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>por {author}</span>}
          </div>
          <h3 style={{ fontSize: 15, fontWeight: 500, color: "var(--color-text-primary)", marginBottom: 4, cursor: "pointer" }} onClick={onView}>{idea.title}</h3>
          {idea.description && <p style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{idea.description}</p>}
          <p style={{ fontSize: 11, color: "var(--color-text-secondary)", marginTop: 6, opacity: 0.7 }}>{idea.createdAt}</p>
        </div>
        <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
          {mine && <IconBtn icon={<Edit2 size={15} />} onClick={onEdit} />}
          {mine && <IconBtn icon={<Trash2 size={15} />} onClick={onDelete} danger />}
          <IconBtn icon={<Eye size={15} />} onClick={onView} />
          {!mine && idea.visibility === "collab" && (
            <button onClick={onRequest} disabled={alreadyRequested} style={{ padding: "5px 12px", background: alreadyRequested ? "var(--color-background-secondary)" : "#dbeafe", color: alreadyRequested ? "var(--color-text-secondary)" : "#2563eb", border: "none", borderRadius: 8, cursor: alreadyRequested ? "default" : "pointer", fontSize: 12, fontFamily: "var(--font-sans)", fontWeight: 500 }}>
              {alreadyRequested ? "Enviado" : "Unirme"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function VisBadge({ v }) {
  const vis = VISIBILITY[v];
  const Icon = vis.icon;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "3px 8px", borderRadius: 20, background: vis.bg, color: vis.color, fontSize: 12, fontWeight: 500 }}>
      <Icon size={11} /> {vis.label}
    </span>
  );
}

function IconBtn({ icon, onClick, danger }) {
  return (
    <button onClick={onClick} style={{ padding: 6, border: "0.5px solid var(--color-border-tertiary)", borderRadius: 8, background: "transparent", cursor: "pointer", color: danger ? "#ef4444" : "var(--color-text-secondary)", display: "flex", alignItems: "center" }}>
      {icon}
    </button>
  );
}

function ProfileView({ user, myIdeas, onLogout, onSave }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: user.name, bio: user.bio || "" });

  function save() {
    onSave({ ...user, name: form.name, bio: form.bio });
    setEditing(false);
  }

  const pubCount = myIdeas.filter(i => i.visibility === "public").length;
  const privCount = myIdeas.filter(i => i.visibility === "private").length;
  const colCount = myIdeas.filter(i => i.visibility === "collab").length;

  return (
    <div>
      <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 16, padding: "1.5rem", marginBottom: "1rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: "1.25rem" }}>
          <div style={{ width: 56, height: 56, borderRadius: "50%", background: "#fce7f3", color: "#9d174d", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, fontWeight: 600, flexShrink: 0 }}>
            {user.name[0].toUpperCase()}
          </div>
          <div style={{ flex: 1 }}>
            {editing ? (
              <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} style={{ ...inputStyle, marginBottom: 6 }} />
            ) : (
              <h2 style={{ fontSize: 18, fontWeight: 600, color: "var(--color-text-primary)" }}>{user.name}</h2>
            )}
            <p style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>{user.email}</p>
          </div>
        </div>

        {editing ? (
          <textarea placeholder="Contá algo sobre vos..." value={form.bio} onChange={e => setForm(p => ({ ...p, bio: e.target.value }))} style={{ ...inputStyle, minHeight: 70 }} />
        ) : (
          <p style={{ fontSize: 14, color: user.bio ? "var(--color-text-primary)" : "var(--color-text-secondary)", lineHeight: 1.6, fontStyle: user.bio ? "normal" : "italic" }}>{user.bio || "Sin bio todavía"}</p>
        )}

        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          {editing ? (
            <>
              <button onClick={save} style={btnPrimary}><Check size={15} /> Guardar</button>
              <button onClick={() => setEditing(false)} style={btnGhost}><X size={15} /> Cancelar</button>
            </>
          ) : (
            <button onClick={() => setEditing(true)} style={btnGhost}><Edit2 size={15} /> Editar perfil</button>
          )}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: "1rem" }}>
        {[["Públicas", pubCount, "#16a34a", "#dcfce7"], ["Privadas", privCount, "#6b7280", "#f3f4f6"], ["Colaborativas", colCount, "#2563eb", "#dbeafe"]].map(([label, count, color, bg]) => (
          <div key={label} style={{ background, borderRadius: 12, padding: "1rem", textAlign: "center" }}>
            <p style={{ fontSize: 22, fontWeight: 600, color }}>{count}</p>
            <p style={{ fontSize: 12, color, opacity: 0.8, marginTop: 2 }}>{label}</p>
          </div>
        ))}
      </div>

      <button onClick={onLogout} style={{ ...btnGhost, color: "#ef4444", borderColor: "#fecaca", width: "100%", justifyContent: "center" }}>
        <LogOut size={15} /> Cerrar sesión
      </button>
    </div>
  );
}

const inputStyle = {
  width: "100%", padding: "10px 12px", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 8,
  background: "var(--color-background-primary)", color: "var(--color-text-primary)", fontSize: 14,
  fontFamily: "var(--font-sans)", outline: "none", boxSizing: "border-box"
};

const btnPrimary = {
  display: "inline-flex", alignItems: "center", gap: 6, padding: "8px 16px",
  background: "#e94560", color: "#fff", border: "none", borderRadius: 8,
  cursor: "pointer", fontSize: 14, fontFamily: "var(--font-sans)", fontWeight: 500
};

const btnGhost = {
  display: "inline-flex", alignItems: "center", gap: 6, padding: "8px 14px",
  background: "transparent", color: "var(--color-text-secondary)",
  border: "0.5px solid var(--color-border-tertiary)", borderRadius: 8,
  cursor: "pointer", fontSize: 14, fontFamily: "var(--font-sans)"
};
